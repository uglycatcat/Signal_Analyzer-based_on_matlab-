%如何令两个通道滚屏的速度相同
%如何解决解决存储每个通道全部数据buffer的变换
a=0;
b=0;
c=1;
if a==b || a==c
    disp(12);
elseif a~=b
    disp(13);
end